const express = require('express');
var plantData = require('../models/plantData');
const plantRouter = express.Router();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const multer =  require('multer');

const storage = multer.diskStorage({
  destination: function(req,file,cb){
    cb(null,'./uploads/');
  },
  filename : function(req,file,cb){
    cb(null,new Date().toISOString() + file.originalname);
  }
});

const upload = multer({storage : storage});

mongoose.connect("mongodb://localhost:27017/PlantDb");

mongoose.set('useFindAndModify', false);
var db=mongoose.connection;
db.on('error',(error)=>{
  console.log(error);
});
db.once('open',()=>{
  console.log("Success");
});


function router() {

  console.log("hi");

  plantRouter.get('',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods: GET , POST , PATCH ,PUT , DELETE , OPTIONS")
    plantData.find()
    .then(function (plants){
      res.send(plants);
    });

  });

  plantRouter.post('/insert',upload.single('imageUrl'),function(req,res){
    // const url = req.protocol + '://' + req.get('host')
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods: GET , POST , PATCH ,PUT , DELETE , OPTIONS")
    console.log(req.body);
    var plant ={
      plantName: req.body.plant.plantName,
      category: req.body.plant.category,
      description: req.body.plant.description,
      location: req.body.plant.location,
      availability: req.body.plant.availability,
      imageUrl: req.file.imageUrl

    }
    var plant = new plantData(plant);
    plant.save();
  });

  return plantRouter;
}

module.exports = router;
