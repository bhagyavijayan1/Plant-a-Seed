import { Component, OnInit } from '@angular/core';
import {  PlantModel} from '../userpage/plants.model';
import { PlantService} from '../plant.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  title: string = 'Plant-List' ;
  plants: PlantModel[];

  // Image Properies
  imageWidth: number = 180;
  imageMargin: number = 2;

  filteredPlants: PlantModel[];
  private _searchTerm: string;

  get searchTerm(): string{
    return this._searchTerm;
  }

  set searchTerm(value: string){
    this._searchTerm = value;
    this.filteredPlants = this.filterPlants(value);
  }

  filterPlants(searchString: string){
    return this.plants.filter(plant => (plant.location.toLowerCase().indexOf(searchString.toLowerCase()) !== -1) ||
    (plant.plantName.toLowerCase().indexOf(searchString.toLowerCase()) !== -1));
  }


  constructor(private plantService: PlantService) { }

  ngOnInit(): void {
    this.plantService.getPlants().subscribe((data) => {
      this.plants = JSON.parse(JSON.stringify(data));
      this.filteredPlants = this.plants;

    });
  }

}
