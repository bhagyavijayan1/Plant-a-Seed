export class PlantModel{
  constructor(
    // public plantId: string,
    public plantName: string,
    public category: string,
    public description: string,
    public location: string,
    public availability: number,
    public imageUrl: string) { }

  }








