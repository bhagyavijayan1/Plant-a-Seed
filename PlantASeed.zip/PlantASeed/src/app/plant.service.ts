import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlantService {


  constructor(private http: HttpClient) { }
  getPlants(){
    return this.http.get('http://localhost:5000/user');
  }

  newPlant(item){
    const formData = new FormData();
    formData.append('imageUrl', item);
    return this.http.post(`http://localhost:5000/user/insert`, {'plant': item})
    .subscribe(data => {
      console.log(data);
      console.log('success');
    });
  }

}
