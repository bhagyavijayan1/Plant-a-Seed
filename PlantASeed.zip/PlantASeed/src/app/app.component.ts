import { Component } from '@angular/core';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PlantASeed';
  showHead: boolean = false;
  showFoot: boolean = false;


  ngOnInit() {
  }

  constructor(private _router: Router) {
    // on route change to '/login', set the variable showHead to false
      _router.events.forEach((event) => {
        if (event instanceof NavigationEnd) {
          if ((event[`url`] === '/login') || (event[`url`] === '/signup') || (event[`url`] === '/contact') ||
          (event[`url`] === '/portfolio') || (event[`url`] === '/user') || (event[`url`] === '/donate') ||
          (event[`url`] === '/adopt') || (event[`url`] === '/admin')) {
            this.showFoot = false;
          } else {
            this.showFoot = true;
          }
        }
      });

      _router.events.forEach((event) => {
        if (event instanceof NavigationStart) {
          if (event[`url`] === '/admin') {
            this.showHead = false;
          } else {
            // console.log("NU")
            this.showHead = true;
          }
        }
      });
    }
}

