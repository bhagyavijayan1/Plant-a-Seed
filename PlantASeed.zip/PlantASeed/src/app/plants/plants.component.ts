import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-plants',
  templateUrl: './plants.component.html',
  styleUrls: ['./plants.component.css']
})
export class PlantsComponent implements OnInit {

  constructor(private _router: Router) { }

  send(){
    this._router.navigate(['/signup']);
  }

  ngOnInit() {
  }

}
