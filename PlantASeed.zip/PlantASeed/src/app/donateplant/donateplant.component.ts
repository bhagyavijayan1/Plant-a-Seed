import { Component, OnInit } from '@angular/core';
import { PlantService } from '../plant.service';
import { Router } from '@angular/router';
import { PlantModel } from '../userpage/plants.model';
import { HttpClient, HttpBackend} from '@angular/common/http';


@Component({
  selector: 'app-donateplant',
  templateUrl: './donateplant.component.html',
  styleUrls: ['./donateplant.component.css']
})
export class DonateplantComponent implements OnInit {

  constructor(private plantService: PlantService , private router: Router , private http: HttpClient) { }
  plantItem = new PlantModel(null, null, null, null, null, null);
  fileToUpload: File = null;
  // imageUrl: string = '../assets/images/logo.png';
  images;

  ngOnInit(): void {
  }
  selectImage(event){
    if (event.target.files.length > 0){
        const file = event.target.files[0];
        this.images = file;
    }

  }

  //Show Image Preview

// var reader = new FileReader();
// reader.onload = (event: any) => {
//             this.imageUrl = event.target.result;
//   };
// reader.readAsDataURL(this.fileToUpload);
//   }

Donate(){
    this.plantService.newPlant(this.plantItem);
    alert('Success');
    this.router.navigate(['/user']);


}
}
